import { InfoPersonagemComponent } from './components/info-personagem/info-personagem.component';
import { ListPersonagensComponent } from './components/list-personagens/list-personagens.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {path:'', redirectTo: '/personagens/1', pathMatch: 'full'},
  {path: 'personagens/:page', component: ListPersonagensComponent},
  {path: 'personagemInfo/:id', component: InfoPersonagemComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
