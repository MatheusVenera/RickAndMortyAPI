import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { MenuComponent } from './components/menu/menu.component';
import { ListPersonagensComponent } from './components/list-personagens/list-personagens.component';
import { HttpClientModule } from '@angular/common/http';
import { InfoPersonagemComponent } from './components/info-personagem/info-personagem.component';

@NgModule({
  declarations: [
    AppComponent,
    MenuComponent,
    ListPersonagensComponent,
    InfoPersonagemComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgbModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
