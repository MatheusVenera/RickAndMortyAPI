import { Personagem } from 'src/app/models/personagem';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { ListaPersonagens } from '../models/lista-personagens';

@Injectable({
  providedIn: 'root'
})
export class RickMortyAPIService {

  constructor(private http: HttpClient) { }

  getPersonagens(page?:number) {
    let url:string = `${environment.urlAPI}/character/?page=${page}`

    return this.http.get<ListaPersonagens>(url);
  }

  gerPersonagemById(id?:number) {
    let url:string = `${environment.urlAPI}/character/${id}`

    return this.http.get<Personagem>(url);
  }
}
