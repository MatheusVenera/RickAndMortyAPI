import { TestBed } from '@angular/core/testing';

import { RickMortyAPIService } from './rick-morty-api.service';

describe('RickMortyAPIService', () => {
  let service: RickMortyAPIService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(RickMortyAPIService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
