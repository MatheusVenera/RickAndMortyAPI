import { ActivatedRoute, Router } from '@angular/router';
import { RickMortyAPIService } from './../../services/rick-morty-api.service';
import { Component, OnInit } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { ListaPersonagens } from 'src/app/models/lista-personagens';
import { Personagem } from 'src/app/models/personagem';

@Component({
  selector: 'app-list-personagens',
  templateUrl: './list-personagens.component.html',
  styleUrls: ['./list-personagens.component.scss']
})
export class ListPersonagensComponent implements OnInit {

  page = Number.parseInt(this.route.snapshot.paramMap.get('page') ?? '');
  listaPersonagens$ = new Subject<Personagem[]>();
  constructor(private rickMortyService: RickMortyAPIService, private route: ActivatedRoute, private router:Router) { }

  ngOnInit(): void {
    const page = Number.parseInt(this.route.snapshot.paramMap.get('page') ?? '1');
    this.rickMortyService.getPersonagens(this.page).subscribe((response) => {this.listaPersonagens$.next(response.results);
    this.page = page;
    this.page = this.page + 1;
  })}

  public NextPage() {
    const page = Number.parseInt(this.route.snapshot.paramMap.get('page') ?? '1');
    this.rickMortyService.getPersonagens(this.page).subscribe((response) => {this.listaPersonagens$.next(response.results);
    this.page = page;
    this.page = this.page + 1;
    this.router.navigate(['personagens',(this.page)]);
    window.location.reload();
  })}

};

