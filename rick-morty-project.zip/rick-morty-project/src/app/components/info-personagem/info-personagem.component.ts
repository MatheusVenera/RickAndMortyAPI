import { Subject } from 'rxjs';
import { RickMortyAPIService } from './../../services/rick-morty-api.service';
import { Personagem } from 'src/app/models/personagem';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-info-personagem',
  templateUrl: './info-personagem.component.html',
  styleUrls: ['./info-personagem.component.scss']
})
export class InfoPersonagemComponent implements OnInit {

  personagem = new Personagem({});
  constructor(private rickMortyService: RickMortyAPIService, private route: ActivatedRoute) { }

  ngOnInit(): void {
    const id = Number.parseInt(this.route.snapshot.paramMap.get('id') ?? '');
    this.rickMortyService.gerPersonagemById(id).subscribe((response) => (this.personagem = response));
  }

}
