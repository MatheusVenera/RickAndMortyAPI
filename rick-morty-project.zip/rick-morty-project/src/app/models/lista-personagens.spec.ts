import { ListaPersonagens } from './lista-personagens';

describe('ListaPersonagens', () => {
  it('should create an instance', () => {
    expect(new ListaPersonagens()).toBeTruthy();
  });
});
