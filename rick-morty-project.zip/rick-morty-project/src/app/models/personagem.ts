export class Personagem {
  id?: number;
  name?: string;
  status?: string;
  gender?: string;
  image?: string;

  constructor(object: Partial<Personagem>){
    Object.assign(this, object);
  }
}
