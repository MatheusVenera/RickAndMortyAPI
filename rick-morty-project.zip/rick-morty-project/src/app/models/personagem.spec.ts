import { Personagem } from './personagem';

describe('Personagem', () => {
  it('should create an instance', () => {
    expect(new Personagem()).toBeTruthy();
  });
});
