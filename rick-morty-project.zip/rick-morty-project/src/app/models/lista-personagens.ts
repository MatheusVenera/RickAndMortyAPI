import { Personagem } from './personagem';
export class ListaPersonagens {
  results: Personagem[] = [];
}
